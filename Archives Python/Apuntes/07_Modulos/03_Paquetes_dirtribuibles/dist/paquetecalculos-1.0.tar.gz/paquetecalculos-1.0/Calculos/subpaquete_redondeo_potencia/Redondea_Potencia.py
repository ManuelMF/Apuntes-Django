def potencia(base,exponente):
	return base**exponente

def redondear(numero):
	return round(numero)