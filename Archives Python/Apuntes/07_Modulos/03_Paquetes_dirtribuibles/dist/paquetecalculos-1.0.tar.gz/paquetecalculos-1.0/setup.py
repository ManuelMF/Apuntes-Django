from setuptools import setup

setup(

	name="paquetecalculos",
	version="1.0",
	description="Paquete de redondeo y potencia",
	author="Manuel",
	author_email="mmf19500@gmail.com",
	url="www.miweb.es",
	packages=["Calculos","Calculos.subpaquete_redondeo_potencia"]
	)